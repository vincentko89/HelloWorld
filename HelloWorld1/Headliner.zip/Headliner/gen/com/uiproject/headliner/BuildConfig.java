/** Automatically generated file. DO NOT MODIFY */
package com.uiproject.headliner;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}